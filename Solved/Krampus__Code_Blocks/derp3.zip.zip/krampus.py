_ = raw_input()
try:
	print (eval(_))
except:
	exec(_)